using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.IO;
// using System.Windows.Forms;
// using System.Drawing;

namespace FileDownloader7;

public enum ServerType
{
    None = 0,
    FileServer,
    AwsS3,
}

public class FileDownloaderItem
{
    public ServerType ServerType { get; private set; } = ServerType.None;
    public string Url { get; private set; }
    public string FileName { get; private set; }
    public string DownloadPath { get; private set; }

    // public TextProgressBar ProgressBar { get; private set; } = default!;
    // // public Label StatusLabel { get; private set; } = default!;
    // // public Label UrlLabel { get; private set; } = default!;
    // public Panel Panel { get; private set; } = default!;

    public long TotalBytesReceived { get; set; } = 0;
    public long TotalFileSize { get; set; } = 0;
    public bool IsComplete { get; set; } = false;

    public event Action? ProgressUpdated;
    public event Action<FileDownloaderItem, string>? StatusUpdated;

    public FileDownloaderUI UI { get; private set; }


    public FileDownloaderItem(string url, string folderPath, ServerType serverType)
    {
        this.ServerType = serverType;

        this.IsComplete = false;

        this.Url = url;
        FileName = Path.GetFileName(url); ;
        DownloadPath = Path.Combine(folderPath, Path.GetFileName(url));

        this.TotalBytesReceived = 0;
        this.TotalFileSize = 0;

        this.UI = new FileDownloaderUI(url);

        // InitializeComponents__();
        // InitializeTotalBytesReceived();
    }

    // private void InitializeComponents()
    // {
    //     Panel = new Panel { Width = 400, Height = 20 };
    //     ProgressBar = new TextProgressBar { Width = 350, Height = 18, CustomText = FileName, VisualMode = ProgressBarDisplayMode.TextAndPercentage, Location = new Point(0, 0) };
    //     // StatusLabel = new Label { Width = 300, Location = new Point(0, 35) };
    //     // UrlLabel = new Label { Text = FileName, Width = 300, Location = new Point(0, 0) };

    //     // Add ProgressBar and StatusLabel to Panel
    //     Panel.Controls.Add(ProgressBar);
    //     // Panel.Controls.Add(StatusLabel);

    //     // Add URL Label to ProgressBar
    //     // Panel.Controls.Add(UrlLabel);
    // }

    public void InitializeTotalBytesReceived()
    {
        this.TotalBytesReceived = 0;
        for (int i = 0; ; i++)
        {
            string tempFilePath = $"{DownloadPath}.part{i}";
            if (!File.Exists(tempFilePath))
            {
                break;
            }
            this.TotalBytesReceived += new FileInfo(tempFilePath).Length;
        }

        Logger.Log($"[InitializeTotalFileSize][{this.Url}] TotalBytesReceived: {this.TotalBytesReceived}");
    }

    public async void InitializeTotalFileSize(string apiKey)
    {
        // TotalFileSize = await DownloadHelper.GetFileSizeAsync(Url, apiKey);
        await DownloadHelper.GetFileSizeAsync(this.Url, apiKey).ContinueWith(task =>
        {
            this.TotalFileSize = task.Result;
            Logger.Log($"[InitializeTotalFileSize][{this.Url}] TotalFileSize: {this.TotalFileSize}");
        });
    }

    public async void InitializeTotalFileSize(AmazonS3Client s3Client, string bucketName)
    {
        string s3FilePath = Utils.ExtractFilePathFromUrl(this.Url);

        await DownloadHelper.GetFileSizeAsync_S3(s3Client, bucketName, s3FilePath).ContinueWith(task =>
        {
            this.TotalFileSize = task.Result;
            Logger.Log($"[InitializeTotalFileSize(S3)][{this.Url}] TotalFileSize: {this.TotalFileSize}");
        });
    }

    public (Task, CancellationTokenSource) ExecuteTask(string apiKey, Action<Action> uiUpdater)
    {
        CancellationTokenSource cts = new();

        var task = Task.Run(() => DownloadHelper.DownloadFileAsync(apiKey, this, uiUpdater, cts)).ContinueWith(task =>
        {
            if (task.Result)
            {
                this.IsComplete = true;
                Logger.Log($"[ExecuteTask][{this.Url}] 다운로드 완료:{task.Result}");
            }
            else
            {
                this.IsComplete = false;
                Logger.ErrorLog($"[ExecuteTask][{this.Url}] 다운로드 오류: {task.Exception?.Message}");
            }
        });

        return (task, cts);
    }

    public (Task, CancellationTokenSource) ExecuteTask(AmazonS3Client s3Client, string bucketName, Action<Action> uiUpdater)
    {
        CancellationTokenSource cts = new();

        var task = Task.Run(() => DownloadHelper.DownloadFileAsync_S3(s3Client, bucketName, this, uiUpdater, cts)).ContinueWith(task =>
        {
            if (task.Result)
            {
                this.IsComplete = true;
                Logger.Log($"[ExecuteTask(S3)][{this.Url}] 다운로드 완료:{task.Result}");
            }
            else
            {
                this.IsComplete = false;
                Logger.ErrorLog($"[ExecuteTask(S3)][{this.Url}] 다운로드 오류: {task.Exception?.Message}");
            }
        });

        return (task, cts);
    }

    public void UpdateProgress(long bytesReceived, long totalBytes)
    {
        // if (totalBytes == 0)
        // {
        //     Logger.ErrorLog($"{Url} - 다운로드 오류: {"totalBytes == 0"}");
        //     return;
        // }

        // ProgressBar.Maximum = (int)totalBytes;
        // ProgressBar.Value = (int)bytesReceived;
        this.UI.UpdateProgress(this.Url, bytesReceived, totalBytes);

        this.ProgressUpdated?.Invoke();
    }

    public void UpdateStatus(UpdateStatus status, string statusMessage)
    {
        // StatusLabel.Text = status;
        this.UI.UpdateStatus(this.Url, statusMessage);

        this.StatusUpdated?.Invoke(this, statusMessage);
    }

    public bool IsChecksum(string checksum)
    {
        return Utils.CalculateMD5FromFile(DownloadPath) == checksum;
    }
}


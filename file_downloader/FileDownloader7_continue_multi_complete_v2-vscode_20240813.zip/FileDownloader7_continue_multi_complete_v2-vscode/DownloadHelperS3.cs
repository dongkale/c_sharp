using Amazon.S3;
using Amazon.S3.Model;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace FileDownloader7;

public static class DownloadHelperS3
{
    public const int DEFAULT_FILE_PART_COUNT = 4;

    private static bool _isPaused = false;
    private static object _pauseLock = new object();

    public static async Task<bool> DownloadFileAsync(AmazonS3Client s3Client, string bucketName, FileDownloaderItem item, Action<Action> uiUpdater, CancellationTokenSource cancellationToken, int partCount = DEFAULT_FILE_PART_COUNT)
    {
        long totalFileSize = 0;
        long totalBytesReceived = item.TotalBytesReceived;

        Logger.Log($"[DownloadFileAsync][TotalBytesReceived] {item.Url} - {item.TotalBytesReceived}");

        if (File.Exists(item.DownloadPath))
        {
            totalBytesReceived = new FileInfo(item.DownloadPath).Length;

            string checksum = Utils.CalculateMD5FromFile(item.DownloadPath);
            Logger.Log($"[DownloadFileAsync][Checksum] {item.DownloadPath} - {checksum}");
        }

        try
        {
            // string s3FilePath = "test/newest.txt";  // Utils.ExtractFilePathFromUrl(item.Url);
            string s3FilePath = Utils.ExtractFilePathFromUrl(item.Url);

            // Get the total file size from S3
            var metadataResponse = await s3Client.GetObjectMetadataAsync(new GetObjectMetadataRequest
            {
                BucketName = bucketName,
                Key = s3FilePath
            });

            totalFileSize = metadataResponse.ContentLength;
            item.TotalFileSize = totalFileSize;

            Logger.Log($"[DownloadFileAsync][TotalFileSize][{item.Url}] {item.TotalFileSize}");

            if (totalBytesReceived >= totalFileSize)
            {
                uiUpdater(() => item.UpdateStatus(UpdateStatus.AlreadyCompleted, "ALREADY DOWNLOAD"));
                Logger.Log($"[DownloadFileAsync][{item.Url}] {item.DownloadPath} - 다운로드 완료된 파일");
                return true;
            }

            // Adjust part count if file is too small
            if (totalFileSize < partCount)
            {
                partCount = 1;
            }

            long partSize = totalFileSize / partCount;
            List<Task> downloadTasks = new List<Task>();
            for (int i = 0; i < partCount; i++)
            {
                long start = i * partSize;
                long end = (i == partCount - 1) ? totalFileSize - 1 : (start + partSize - 1);
                downloadTasks.Add(DownloadPartFromAsync(s3Client, bucketName, s3FilePath, item, start, end, i, uiUpdater, cancellationToken.Token));
            }

            await Task.WhenAll(downloadTasks);

            CombineParts(item.DownloadPath, partCount);

            uiUpdater(() => item.UpdateStatus(UpdateStatus.Complete, "DOWNLOAD COMPLETE"));

            return true;
        }
        catch (Exception ex)
        {
            Logger.ErrorLog($"[DownloadFileAsync] {item.Url} {ex.Message}");
            uiUpdater(() => item.UpdateStatus(UpdateStatus.Error, "DOWNLOAD FAIL: " + ex.Message));

            DeletePartFiles(item.DownloadPath, partCount);
            return false;
        }
    }

    private static async Task DownloadPartFromAsync(AmazonS3Client s3Client, string bucketName, string s3FilePath, FileDownloaderItem item, long start, long end, int partIndex, Action<Action> uiUpdater, CancellationToken cancellationToken)
    {
        string tempFilePath = $"{item.DownloadPath}.part{partIndex}";
        long existingLength = 0;

        if (File.Exists(tempFilePath))
        {
            existingLength = new FileInfo(tempFilePath).Length;
            if (existingLength >= (end - start + 1))
            {
                // Skip downloading if the part is already complete
                return;
            }
            start += existingLength;
        }

        Logger.Log($"[DownloadPartFromS3Async][{item.Url}] file: {Path.GetFileName(tempFilePath)}, start: {start}, end: {end}, existingLength: {existingLength}");

        var request = new GetObjectRequest
        {
            BucketName = bucketName,
            Key = s3FilePath,
            ByteRange = new ByteRange(start, end)
        };

        using (GetObjectResponse response = await s3Client.GetObjectAsync(request))
        using (Stream responseStream = response.ResponseStream)
        using (FileStream fileStream = new FileStream(tempFilePath, FileMode.Append, FileAccess.Write, FileShare.None))
        {
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = await responseStream.ReadAsync(buffer, 0, buffer.Length, cancellationToken)) > 0)
            {
                // Pause logic
                await CheckForPauseAsync();

                fileStream.Write(buffer, 0, bytesRead);
                lock (item)
                {
                    item.TotalBytesReceived += bytesRead;
                    uiUpdater(() => item.UpdateProgress(item.TotalBytesReceived, item.TotalFileSize));
                }
            }
        }
    }

    // 모두 task 취소: 예외 발생해서 part 까지 다 지운다.(이어받기 안됨)
    public static void CancelDownloads(CancellationTokenSource[] items)
    {
        foreach (var item in items)
        {
            item.Cancel();
        }
    }

    private static async Task CheckForPauseAsync()
    {
        while (_isPaused)
        {
            await Task.Delay(100);
        }
    }

    public static void PauseDownload()
    {
        lock (_pauseLock)
        {
            _isPaused = true;
        }
    }

    public static void ResumeDownload()
    {
        lock (_pauseLock)
        {
            _isPaused = false;
        }
    }

    private static void CombineParts(string downloadPath, int partCount)
    {
        using (FileStream output = new FileStream(downloadPath, FileMode.Create))
        {
            for (int i = 0; i < partCount; i++)
            {
                string tempFilePath = $"{downloadPath}.part{i}";
                if (File.Exists(tempFilePath))
                {
                    using (FileStream input = new FileStream(tempFilePath, FileMode.Open))
                    {
                        input.CopyTo(output);
                    }
                    File.Delete(tempFilePath);

                    Logger.Log($"[CombineParts][Delete] {Path.GetFileName(tempFilePath)}({downloadPath})");
                }
            }
        }
    }

    private static void DeletePartFiles(string downloadPath, int partCount)
    {
        for (int i = 0; i < partCount; i++)
        {
            string tempFilePath = $"{downloadPath}.part{i}";
            if (File.Exists(tempFilePath))
            {
                File.Delete(tempFilePath);
                Logger.Log($"[DeletePartFiles][Delete] {Path.GetFileName(tempFilePath)}");
            }
        }
    }

    public static void DeleteAllPartFiles(string downloadPath)
    {
        string filepath = Path.GetDirectoryName(downloadPath) ?? String.Empty;
        if (String.IsNullOrEmpty(filepath))
        {
            return;
        }

        string filename = Path.GetFileName(downloadPath);

        foreach (string tempFilePath in Directory.EnumerateFiles(filepath, $"{filename}.part*"))
        {
            if (File.Exists(tempFilePath))
            {
                File.Delete(tempFilePath);
                Logger.Log($"[DeleteAllPartFiles][Delete] {Path.GetFileName(tempFilePath)}");
            }
        }
    }

    public static async Task<bool> IsDownloadableAsync(AmazonS3Client s3Client, string bucketName, string s3FilePath)
    {
        try
        {
            var response = await s3Client.GetObjectMetadataAsync(new GetObjectMetadataRequest
            {
                BucketName = bucketName,
                Key = s3FilePath
            });
            return response.HttpStatusCode == System.Net.HttpStatusCode.OK;
        }
        catch (Exception ex)
        {
            Logger.ErrorLog($"S3 URL 확인 중 오류 발생: {ex.Message}");
            return false;
        }
    }

    public static async Task<long> GetFileSizeAsync(AmazonS3Client s3Client, string bucketName, string s3FilePath)
    {
        try
        {
            var response = await s3Client.GetObjectMetadataAsync(new GetObjectMetadataRequest
            {
                BucketName = bucketName,
                Key = s3FilePath
            });
            return response.ContentLength;
        }
        catch (Exception ex)
        {
            Logger.ErrorLog($"S3 파일 크기 확인 중 오류 발생: {ex.Message}");
            return -1;
        }
    }

    public static async Task<(bool, string)> GetFileContentFromAsync(AmazonS3Client s3Client, string bucketName, string s3FilePath)
    {
        try
        {
            var request = new GetObjectRequest
            {
                BucketName = bucketName,
                Key = s3FilePath
            };

            using (GetObjectResponse response = await s3Client.GetObjectAsync(request))
            using (StreamReader reader = new StreamReader(response.ResponseStream))
            {
                string content = await reader.ReadToEndAsync();
                return (true, content);
            }
        }
        catch (Exception ex)
        {
            return (false, $"S3 다운로드 오류: {ex.Message}");
        }
    }
}
